from tkinter import *
import sys
import os
import math

def distance(x1, y1, x2, y2):
    return ((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2)) **0.5

class Circle:
    def __init__(self, x, y, radius):
        
        self.x=x
        self.y=y
        self.radius=radius

    def isInside(self, x, y):
        return distance(self.x, self.y, x, y) <=self.radius
 
   
def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)    
        

class MainGUI:



    def __init__(self):
        self.window = Tk()
        self.window.title("Connect 4 Game")
        self.winMessage = Frame(self.window, width=100, height = 50) # diemsions of the reset label 
        self.winMessage.pack(side = TOP)
        self.canvas = Canvas(self.window,width=630, height =600,bg = 'white') #orig. 630 600
        self.canvas.pack()
        self.instructions = Frame(self.window, width = 100, height = 60)
        self.instructions.pack(side = BOTTOM)
        self.resetFrame = Frame(self.window, width=100, height = 30) # diemsions of the reset label 
        self.resetFrame.pack(side = BOTTOM)
        
        
        self.labelColumnFull = Label(self.winMessage, text = '')
        self.labelColumnFull.pack(side = TOP)
        button = Button(self.resetFrame, text = 'New Game', width = 10, height = 1, command=restart_program)
        button.pack(side = BOTTOM)
        self.label1 = Label(self.winMessage, text = "Start Of Game: Player 1's Turn", font = 'helvectia 18 bold')
        self.label1.pack(side = TOP)
        self.instructLabel = Label (self.instructions,
                                    text = "Instructions: \n -Red goes first \n -To drop a piece down, click on the column you want on the top row. \n - Play again by clicking on the button above")
        self.instructLabel.pack(side = TOP)


        
        self.ROWS = 6
        self.COLUMNS = 7
        self.board = self.create_board()
        self.c=[]
        self.his=[]
        self.t=-1
        self.printBoard(self.board)
        self.gameOver = False
        self.turn = 0
        self.canvas.bind("<Button-1>",self.giveCol)
        self.drawBoard(self.board)
        if self.t > 0:
            self.play()
        
        self.window.mainloop()

    def play(self):
        if not self.gameOver:
            self.labelColumnFull.config(text = "")
            if(self.turn==0):
                #col = int(input("Player 1 type column: "))
                col = self.his[self.t]
                col-=1
                if col>=0 and col<self.COLUMNS:
                    if(self.isValid(self.board,col)) :
                        row = self.getNextRow(self.board,col)
                        self.drop_piece(self.board,row,col,1)
                        if self.winningMove(self.board,1):
                            print("PLAYER 1 Wins")
                            
                            #self.message0 = str('PLAYER 1 WINS')
                            #self.outputText = Label(self.winMessage, text = self.message0).pack(side = TOP)
                            self.gameOver=True
                        
                        self.turn+=1
                        self.turn=self.turn%2
                    else:
                        print("Column is full, choose another option")
                        self.labelColumnFull.config(text = "Column is full, choose another option")
                else:
                        print("Column out of range")
                    
            else:
                
                #col = int(input("Player 2 type column: "))
                col = self.his[self.t]
                col-=1
                if col>=0 and col<=self.COLUMNS:
                    if(self.isValid(self.board,col)):
                        row = self.getNextRow(self.board,col)
                        self.drop_piece(self.board,row,col,2)
                        if self.winningMove(self.board,2):
                            print("PLAYER 2 Wins")
                            

                            #self.message = str('PLAYER 2 WINS')
                            #self.outputText = Label(self.winMessage, text = self.message).pack(side = TOP)
                            self.gameOver=True
                        self.turn+=1
                        self.turn=self.turn%2
                        
                    else:
                        
                        print("Column is full, choose another option")
                        self.labelColumnFull.config(text = "Column is full, choose another option")
                        
                else:
                        print("Column out of range")
            #self.printBoard(self.board)
            self.drawBoard(self.board)
        
            

    def create_board(self):
        board = [[0 for col in range(self.COLUMNS)] for row in range(self.ROWS)]
        return board

    def drop_piece(self,board,row,col,piece):
        board[row][col] = piece

    def isValid(self,board, col):
        return board[self.ROWS-1][col]==0
        
    def getNextRow(self,board,col):
        for r in range(self.ROWS):
            if board[r][col] == 0:
                return r
    def winningMove(self,board,piece):
        #Horizontal
        for c in range(self.COLUMNS-3):
            for r in range(self.ROWS):
                if board[r][c] == piece and board[r][c+1] == piece and board[r][c+2] == piece and board[r][c+3] == piece:
                    return True
        #Vertical
        for c in range(self.COLUMNS):
            for r in range(self.ROWS-3):
                if board[r][c] == piece and board[r+1][c] == piece and board[r+2][c] == piece and board[r+3][c] == piece:
                    return True
        #Diagonals
        for c in range(self.COLUMNS-3):
            for r in range(self.ROWS-3):
                if board[r][c] == piece and board[r+1][c+1] == piece and board[r+2][c+2] == piece and board[r+3][c+3] == piece:
                    return True
        for c in range(self.COLUMNS-3):
            for r in range(3,self.ROWS):
                if board[r][c] == piece and board[r-1][c+1] == piece and board[r-2][c+2] == piece and board[r-3][c+3] == piece:
                    return True

    def drawBoard(self,board):
        self.canvas.delete("cir")
        
        
        
        if self.turn ==0:
            colorac="red"

            #self.label1= Label(self.winMessage, text = "Player 1's turn")
            
            self.label1.config(text = "Player 2 Wins")
            if not self.gameOver:
                self.label1.config(text = "Player 1's Turn")
                
            
            #self.turnmessage = ("Player 1's Turn")
            #self.label1= Label(self.winMessage, text = self.turnmessage)
            #self.label1.pack(side = TOP)
           
            
        elif self.turn ==1:
            colorac="black"
            self.label1.config(text = "Player 1 Wins")
            
            if not self.gameOver:
                self.label1.config(text = "Player 2's Turn")
                
        
            


            
            #self.label1 ['text'] = "Player 2's Turn"
            #self.label1.update()

        
        
        
            
        

        circleRad = 30

        self.canvas.create_line(0,120,630,120)
        self.canvas.create_rectangle(2,120,630,600,fill="blue")
        for i in range(7):   #input circles
            #self.canvas.delete("input"+str(i))
            #self.canvas.create_oval((80+i*80)-circleRad,(80)-circleRad,(80+i*80)+circleRad,(80)+circleRad,activefill=colorac,fill="white",tags="input"+str(i))
            self.c.append( Circle((80+i*80),80,circleRad))
            self.paint(self.c[i],colorac,"input")
        
        for y in range(6):      #board
            for x in range(7):
                if board[5-y][x] == 1:
                    color = "red"
                if board[5-y][x] == 2:
                    color = "black"
                if board[5-y][x] == 0:
                    color = "white"
                self.canvas.create_oval((80+x*80)-circleRad,(80+80+y*80)-circleRad,(80+x*80)+circleRad,(80+80+y*80)+circleRad,fill=color,tags="cir")

    def paint(self, c, color, tags = "stable"):
        self.canvas.create_oval(c.x -c.radius,c.y - c.radius, c.x + c.radius,c.y + c.radius, fill= "white", activefill = color, tags = tags)

    def giveCol(self,event):
        for i in range(7):
            if self.c[i].isInside(event.x, event.y):
                self.his.append(i+1)
                self.t+=1
                self.play()
            
    
    def printBoard(self,board):
        for x in range(self.ROWS):
            for y in range(self.COLUMNS):
                print(board[(self.ROWS-1)-x][y], end=" ")
            print()


    
    

MainGUI()
    

